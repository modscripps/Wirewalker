#ifndef __SVN_REVISION_H
#define __SVN_REVISION_H

#if 0
#define SVNREV "build:34 (modified)"
#else
#define SVNREV "build:34"
#endif

#endif // __SVN_REVISION_H
